"""
PO3 Mentorship Discord Bot
--------------------------
Features:
1. Auto-welcome new members (DM + welcome channel post) + assign the Student role
2. Auto-create a private 1-on-1 channel for each new member
3. Auto-answer FAQs based on keywords typed in any channel

Setup: see README.md for step-by-step instructions.
"""

import os
import discord
from discord.ext import commands

# ---------------------------------------------------------------------------
# CONFIG — fill these in via environment variables (see README.md)
# ---------------------------------------------------------------------------
BOT_TOKEN = os.environ["BOT_TOKEN"]                              # required
GUILD_ID = int(os.environ["GUILD_ID"])                           # your server ID
WELCOME_CHANNEL_ID = int(os.environ["WELCOME_CHANNEL_ID"])       # #welcome channel
STUDENT_ROLE_ID = int(os.environ["STUDENT_ROLE_ID"])             # @Student role
ONE_ON_ONE_CATEGORY_ID = int(os.environ["ONE_ON_ONE_CATEGORY_ID"])  # "PRIVATE — 1-ON-1" category
MENTOR_ROLE_ID = int(os.environ.get("MENTOR_ROLE_ID", "0")) or None  # optional, e.g. staff/mods

# ---------------------------------------------------------------------------
# FAQ — keyword: response. Keys are checked as case-insensitive substrings.
# Edit this list freely — it's the easiest part to customize over time.
# ---------------------------------------------------------------------------
FAQ = {
    "payout": (
        "Payout questions go in #payouts-and-results 💰 — post your screenshot there "
        "and I'll usually see it same day. For payout *process* questions specific to "
        "your funded account, drop it in your 1-on-1 channel."
    ),
    "homework": (
        "Homework for each week is pinned at the top of that week's channel "
        "(#week-1-foundations, #week-2-market-structure, etc). Do it before moving to the next week."
    ),
    "funded account": (
        "Funded account questions specific to your progress go in your private 1-on-1 channel "
        "with me — that way I can actually see your charts and give real feedback."
    ),
    "live q&a": (
        "Live Q&A call links and recordings are posted in #live-qa-calls 🎥. "
        "Check the pinned message for the schedule."
    ),
    "journal": (
        "Journal template is in #documents-and-templates 📂. Post your entries in "
        "#journal-check-ins 🗒 once you're rolling."
    ),
}

# ---------------------------------------------------------------------------
# Bot setup
# ---------------------------------------------------------------------------
intents = discord.Intents.default()
intents.members = True          # required for on_member_join
intents.message_content = True  # required to read message text for FAQ matching

bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (id: {bot.user.id})")


@bot.event
async def on_member_join(member: discord.Member):
    guild = member.guild
    if guild.id != GUILD_ID:
        return

    # 1. Assign the Student role
    role = guild.get_role(STUDENT_ROLE_ID)
    if role:
        try:
            await member.add_roles(role, reason="Auto-assigned on join")
        except discord.Forbidden:
            print(f"Missing permission to assign role to {member}")

    # 2. Post a welcome embed in the welcome channel
    welcome_channel = guild.get_channel(WELCOME_CHANNEL_ID)
    if welcome_channel:
        embed = discord.Embed(
            title="Bienvenue dans PO3",
            description=(
                f"{member.mention} vient de rejoindre le serveur 👋\n\n"
                f"Ton channel privé 1-on-1 est prêt en dessous — c'est là que je vais "
                f"suivre ta progression et te donner du feedback direct.\n\n"
                f"**Avant de commencer, réponds dans ton channel privé :**\n"
                f"Ça fait combien de temps que tu trades, et c'est quoi ton plus gros "
                f"blocage en ce moment?"
            ),
            color=0x1F8A56,  # brand green
        )
        embed.set_footer(text="PO3 Mentorship")
        await welcome_channel.send(embed=embed)

    # 3. Try to DM the new member too (some users have DMs closed, so this can fail silently)
    try:
        await member.send(
            "Welcome to PO3! Your private 1-on-1 channel is set up in the server — "
            "that's where I'll drop anything personalized for you. Answer the "
            "onboarding question there, then start with #week-1-foundations when "
            "you're ready."
        )
    except discord.Forbidden:
        pass

    # 4. Create a private 1-on-1 channel for this member
    category = guild.get_channel(ONE_ON_ONE_CATEGORY_ID)
    if category is None:
        print("ONE_ON_ONE_CATEGORY_ID not found — skipping private channel creation")
        return

    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        member: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
        guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True),
    }
    if MENTOR_ROLE_ID:
        mentor_role = guild.get_role(MENTOR_ROLE_ID)
        if mentor_role:
            overwrites[mentor_role] = discord.PermissionOverwrite(view_channel=True, send_messages=True)

    # channel name: lowercase, dashes instead of spaces, discord-safe
    safe_name = "".join(c if c.isalnum() else "-" for c in member.display_name).lower().strip("-")
    channel_name = f"{safe_name or member.id}"

    try:
        new_channel = await category.create_text_channel(
            name=channel_name,
            overwrites=overwrites,
            topic=f"Private 1-on-1 channel for {member.display_name}",
        )
        await new_channel.send(
            f"Hey {member.mention} — this is your private channel. I'll post your "
            f"personalized documents, trade plans, and any custom notes here.\n\n"
            f"**Pour commencer :** ça fait combien de temps que tu trades, et c'est "
            f"quoi ton plus gros blocage en ce moment?"
        )
    except discord.Forbidden:
        print(f"Missing permission to create channel for {member}")


@bot.event
async def on_message(message: discord.Message):
    # Don't respond to the bot's own messages
    if message.author.bot:
        return

    content_lower = message.content.lower()
    for keyword, response in FAQ.items():
        if keyword in content_lower:
            await message.channel.send(response)
            break  # only fire the first match per message

    # Required so other commands (if you add any later) still work
    await bot.process_commands(message)


if __name__ == "__main__":
    bot.run(BOT_TOKEN)
